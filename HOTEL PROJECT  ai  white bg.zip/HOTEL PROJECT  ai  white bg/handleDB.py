import sqlite3


class HandleDB:
    def __init__(self):
        self.conn = sqlite3.connect('record.db')
        self.cursor = self.conn.cursor()
        self.createUserTable()
        self.createCustomertable()
        self.createRoomtable()
        self.createBookingtable()
        self.createCheckintable()
        self.createCheckouttable()
        self.createPaymenttable()
        self.createStafftable()
        self.createFoodtable()

    
    def createUserTable(self):
        query = """
                    create table if not exists Users (
                        email varchar(100) primary key,
                        firstname varchar(15) not null,
                        lastname varchar(15) not null,
                        password varchar(15) not null,
                        contactno varchar(10) not null
                    )
                """
        self.cursor.execute(query)
        print('User table created')
   
    
    def createCustomertable(self):
        query = """
                    create table if not exists Customer (
                        name varchar(100) primary key,
                        mobileno varchar(15) not null,
                        idproof varchar(15) not null,
                        idproofnumber varchar(15) not null
                    )
                """
        self.cursor.execute(query)
        print('Customer table created')

    
    def createRoomtable(self):
        query = """
                    create table if not exists Room (
                        Roomno varchar(100) primary key,
                        Roomtype varchar(15) not null,
                        roomprice varchar(15) not null,
                        Roomstatus varchar(15) not null
                    )
                """
        self.cursor.execute(query)
        print('Room table created')

    def createBookingtable(self):
        query = """
                    create table if not exists Booking (
                        Bookingid varchar(15) primary key,
                        Customerid varchar(15) not null,
                        Roomno varchar(15) not null,
                        Checkin varchar(15) not null,
                        Checkout varchar(15) not null
                    )
                """
        self.cursor.execute(query)
        print('Booking table created')



    def createCheckintable(self):
        # self.cursor.execute("drop table Checkin")
        # self.conn.commit()
        query = """
                    create table if not exists Checkin (
                        Customerid varchar(10) primary key,
                        Checkindate varchar(15) not null,
                        Checkoutdate varchar(15) not null
                    )
                """
        self.cursor.execute(query)
        print('Checkin table created')

    def createCheckouttable(self):
        # self.cursor.execute("drop table Checkout")
        # self.conn.commit()
        query = """
                    create table if not exists Checkout (
                        Customerid varchar(10) primary key,
                        Name varchar(15) not null,
                        Roomnumber varchar(15) not null,
                        Mobilenumber varchar(15) not null,
                        Checkout varchar(15) not null
                    )
                """
        self.cursor.execute(query)
        print('Checkout table created')


    def createPaymenttable(self):
        query = """
                    create table if not exists Payment (
                        Paymentid INTEGER PRIMARY KEY AUTOINCREMENT,
                        Bookingid varchar(10) not null,
                        Guestname varchar(10) not null,
                        Amount varchar(10) not null,
                        txnrefno varchar(20),
                        tnxtype varchar(20) not null
                    )
                """
        self.cursor.execute(query)
        print('Payment table created')

    def createStafftable(self):

        query = """
                    create table if not exists Staff (
                        Staffname varchar(10) primary key,
                        Staffid varchar(10) not null,
                        Gender varchar(10) not null,
                        Designation varchar(10) not null,
                        Department varchar(10) not null,
                        Mobileno varchar(10) not null,
                        Shift varchar(10) not null,
                        Salary varchar(10) not null,
                        Joiningdate varchar(10) not null,
                        Status varchar(15) not null
                    )
                """
        self.cursor.execute(query)
        print('Staff table created')

    def createFoodtable(self):
        query = """
                    create table if not exists Food (
                        Customerid varchar(10),
                        Customername varchar(10),
                        Roomnumber varchar(10) not null,
                        Foodname varchar(10) not null,
                        Quantity varchar(10) not null,
                        Timings varchar(10) not null
                    )
                """
        self.cursor.execute(query)
        print('Food table created')





    def saveUser(self, email, firstname, lastname, password, contactno):
        try:
            self.cursor.execute("insert into Users (email, firstname, lastname, password, contactno) values (?,?,?,?,?)", (email, firstname, lastname, password, contactno))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except:
            return 4
    
    def validateUser(self, username, password):
        self.cursor.execute("select count(*) from users where email = ? and password = ?", (username, password))
        c = self.cursor.fetchone()
        return c 
    

    def allusers(self):
        self.cursor.execute("Select * from users")
        print(self.cursor.fetchall())

    
    def updatepassword(self, email ,password):
        update_query = "UPDATE Users SET password = ? where email = ?"
        self.cursor.execute(update_query,(email,password))
        print('update successfully')
        self.conn.commit()


    def login(self,email,password):
        Data = "SELECT * FROM Users where email=? and password=?"
        self.cursor.execute(Data,(email,password))
        data =self.cursor.fetchone()
        print(data)

        
    def Addcustomer(self, name, mobileno, idproof, idproofnumber):
        try:
            self.cursor.execute("insert into Customer (name, mobileno, idproof, idproofnumber) values(?, ?, ?,?)",(name, mobileno, idproof, idproofnumber))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except:
            return 4  
    def CustomerDetails(self):
        self.cursor.execute("Select * from Customer")
        return self.cursor.fetchall()

        
    def Addroom(self,roomno,roomtype,roomprice,roomstatus):
        try:
            self.cursor.execute("insert into Room (roomno, roomtype, roomprice, roomstatus) values(?, ?, ?,?)",(roomno, roomtype, roomprice,roomstatus))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except:
            return 4
    def RoomDetails(self):
        self.cursor.execute("Select * from Room ")
        return self.cursor.fetchall()


    def Addbooking(self,bookingid ,customerid, roomno, checkin ,checkout):
        try:
            self.cursor.execute("insert into Booking (bookingid ,customerid, roomno, checkin ,checkout) values(?,?, ?,?, ?)",(bookingid ,customerid, roomno, checkin ,checkout))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except Exception as e:
            print(e)
            return 4
    def BookingDetails(self):
        self.cursor.execute("Select * from Booking")
        return self.cursor.fetchall()
 

    def Addcheckin(self,Customerid,checkindate,checkoutdate):
        try:
            self.cursor.execute("insert into Checkin (Customerid,checkindate,checkoutdate) values(?,?, ?)",(Customerid,checkindate,checkoutdate))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except:
            return 4
    def CheckinDetails(self):
        self.cursor.execute("Select Customerid,checkindate,checkoutdate FROM Checkin")
        return self.cursor.fetchall()


    def Addcheckout(self,Customerid,Name,Roomnumber,mobilenumber,checkout):
        try:
            self.cursor.execute("insert into Checkout(Customerid,Name,Roomnumber,mobilenumber,checkout) values(?, ?, ?,?,?)",(Customerid,Name,Roomnumber,mobilenumber,checkout))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except:
            return 4
    def CheckoutDetails(self):
        self.cursor.execute("Select Customerid,Name,Roomnumber,mobilenumber,checkout from Checkout")
        return self.cursor.fetchall()

    def Addpayment(self, bookingid, guestname,amount, txnrefno, tnxtype):
        try:
            self.cursor.execute("insert into Payment(bookingid,guestname,amount, txnrefno, tnxtype) values(?, ?, ?, ?,?)",( bookingid, guestname ,amount, txnrefno, tnxtype))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except:
            return 4
    def PaymentDetails(self):
        self.cursor.execute("Select bookingid,guestname,amount,txnrefno,tnxtype FROM Payment")
        return self.cursor.fetchall()

    def Addstaff(self,staffname,staffid,gender,Designation,Department,Mobileno,Shift,Salary,JoiningDate,Status ):
        try:
            self.cursor.execute("insert into Staff(staffname,staffid,gender,Designation,Department,Mobileno,Shift,Salary,JoiningDate,Status) values(?, ?, ?,  ?, ?, ?, ?, ?, ?, ?)",(staffname,staffid,gender,Designation,Department,Mobileno,Shift,Salary,JoiningDate,Status))
            self.conn.commit()
            if self.cursor.rowcount > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except Exception as e:
            print(e)
            return 4
    def StaffDetails(self):
        self.cursor.execute("Select * from Staff")
        return self.cursor.fetchall()

    def AddFood(self,customerid,Customername,Roomnumber, Foodname,Quantity,Timings):
        try:
            self.cursor.execute("insert into Food(customerid,Customername,Roomnumber, Foodname,Quantity,Timings ) values(?, ?, ?,?, ?,?)",(customerid, Customername,Roomnumber, Foodname,Quantity,Timings ))
            self.conn.commit()
            if self.cursor.rowcount  > 0:
                return 1
            else: 
                return 2
        except sqlite3.IntegrityError:
            return 3
        except Exception as e:
            print(e)
            return 4
    def FoodDetails(self):
        self.cursor.execute("Select * from Food")
        return self.cursor.fetchall()


    def Bookingdata(self,bookingid,):
        self.cursor.execute("Select bookingid,guestname,totalamount,pendingamount from BookingDetails where bookingid = ?",(bookingid,))
        return self.cursor.fetchone()
    
    def getAmount(self,roomno):
        self.cursor.execute("select roomprice from room where roomno = ?",(roomno,))
        return self.cursor.fetchone()
    
    def getRoomno (self):
        self.cursor.execute("Select Roomno from room")
        return self.cursor.fetchall()
    

    def getCheckin(self, bookingid):
        self.cursor.execute("SELECT CustomerID,Checkin,checkout FROM Booking where bookingid = ?", (bookingid,))
        return self.cursor.fetchone()
    

    def getCheckout(self,bookingid):
        query1="SELECT Customerid,roomno,checkout FROM Booking where bookingid = ?"
        self.cursor.execute(query1,(bookingid,))
        data = self.cursor.fetchone()
        query2="SELECT name, Mobileno FROM Customer where idproofnumber = ?"
        self.cursor.execute(query2,(data[0],))
        data2 = self.cursor.fetchone()
        print(data2)
        if data is None or data2 is None:
            return None
        return (data[0], data2[0], data[1], data2[1], data[2])


    def getPaymentBookingData(self, bookingid):
    # Booking table se customer id aur room number nikaalo
        query1 = "SELECT Customerid, Roomno FROM booking WHERE bookingid = ?"
        self.cursor.execute(query1, (bookingid,))
        data = self.cursor.fetchone()

        if data is None:
            return None

        cid = data[0]
        roomno = data[1]
        # Customer table se name lo
        query2 = "SELECT name FROM customer WHERE idproofnumber = ?"
        self.cursor.execute(query2, (cid,))
        customer = self.cursor.fetchone()

        if customer:
            customerName = customer[0]
        else:
            customerName = ""
        # Room table se price lo
        query3 = "SELECT roomprice FROM room WHERE roomno = ?"
        self.cursor.execute(query3, (roomno,))
        room = self.cursor.fetchone()
        if room:
            price = room[0]
        else:
            price = 0

        # Pending amount (abhi simple same rakh diya)
        pendingamount = price
        return (customerName, price)
    

    def getfood(self, bookingid):
        # booking table se customer id aur room no
        query = "SELECT Customerid, roomno FROM Booking WHERE bookingid = ?"
        self.cursor.execute(query, (bookingid,))
        Customerid, roomno = self.cursor.fetchone()
        # customer table se name
        query2 = "SELECT name FROM customer WHERE idproofnumber = ?"
        self.cursor.execute(query2, (Customerid,))
        name = self.cursor.fetchone()[0]
        return Customerid, name, 



    def getTotalRooms(self):
        self.cursor.execute("SELECT COUNT(*) FROM Room")
        return self.cursor.fetchone()[0]


    def getAvailableRooms(self):
        self.cursor.execute("SELECT COUNT(*) FROM Room WHERE roomstatus='Available'")
        return self.cursor.fetchone()[0]


    def getTotalBooking(self):
        self.cursor.execute("SELECT COUNT(*) FROM Booking")
        return self.cursor.fetchone()[0]


    def getTotalCustomer(self):
        self.cursor.execute("SELECT COUNT(*) FROM Customer")
        return self.cursor.fetchone()[0]


    def getBookedRooms(self):
        self.cursor.execute("SELECT COUNT(*) FROM Room WHERE roomstatus='Occupied'")
        return self.cursor.fetchone()[0]


    def getCheckin(self):
        self.cursor.execute("SELECT COUNT(*) FROM Checkin")
        return self.cursor.fetchone()[0]


    def getFood(self):
        self.cursor.execute("SELECT COUNT(*) FROM Food")
        return self.cursor.fetchone()[0]


    def getTotalPayment(self):
        self.cursor.execute("SELECT SUM(amount) FROM Payment")
        result = self.cursor.fetchone()[0]
        return result if result else 0
        

        

if __name__ == '__main__':
    obj = HandleDB()
    # obj.saveUser('abc@ff.com', 'abc','xyz','111','9876545678')
    # obj.validateUser('abc@ff.com', '111')
    # obj.allusers()
    # obj.CustomerDetails()
    # obj.RoomDetails()
    # obj.BookingDetails()
    # obj.CheckinDetails()
    # obj.CheckoutDetails()
    # obj.PaymentDetails()
    # obj.StaffDetails()
    # obj.FoodDetails()
    # obj.getRoomno()
    # obj.getPaymentBookingData(1100)
    # obj.getCheckin(1100)
    # obj.getCheckout(1400)
    # obj.getfood(1300)
    # obj.deletePayment(1500)

