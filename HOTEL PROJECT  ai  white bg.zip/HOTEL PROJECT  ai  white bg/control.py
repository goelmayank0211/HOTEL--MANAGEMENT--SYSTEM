from PyQt5 import QtCore, QtGui, QtWidgets
import window as ui
import sys
import handleDB as db
from PyQt5.QtWidgets import QTableWidgetItem, QMessageBox

class Handler:
    def __init__(self):
        app = QtWidgets.QApplication(sys.argv)
        MainWindow = QtWidgets.QMainWindow()
        self.ui = ui.Ui_MainWindow()
        self.ui.setupUi(MainWindow)
        self.db = db.HandleDB()
        self.updateComboboxes()
        self.loadDashboard()
        self.ui.pushButton.clicked.connect(self.showHotelManagementDashboard)
        self.ui.pushButton_2.clicked.connect(self.showSignUp)
        self.ui.pushButton_3.clicked.connect(self.showForgotPassword)
        self.ui.pushButton_11.clicked.connect(self.showCustomerDetails)
        self.ui.pushButton_9.clicked.connect(self.showRoomDetails)
        self.ui.pushButton_10.clicked.connect(self.showBookingDetails)
        self.ui.pushButton_14.clicked.connect(self.showCheckin)
        self.ui.pushButton_15.clicked.connect(self.showCheckout)
        self.ui.pushButton_8.clicked.connect(self.showPaymentDetails)
        self.ui.pushButton_13.clicked.connect(self.showstaffdetails)
        self.ui.pushButton_12.clicked.connect(self.showfoodetails)
        self.ui.pushButton_6.clicked.connect(self.showHotelroyalin)
        self.ui.pushButton_19.clicked.connect(self.showsignup)
        self.ui.pushButton_25.clicked.connect(self.logout)
        self.ui.pushButton_7.clicked.connect(self.Dashboard)
        self.ui.pushButton_37.clicked.connect(self.ShowDetails)
        
        
        self.ui.pushButton_4.clicked.connect(self.performSignup)
        self.ui.pushButton.clicked.connect(self.performLogin)
        self.ui.pushButton_5.clicked.connect(self.performForgotPassword)
        self.ui.pushButton_18.clicked.connect(self.performCustomerDetails)
        self.ui.pushButton_17.clicked.connect(self.performRoomdetails)
        self.ui.pushButton_16.clicked.connect(self.performBookingDetails)
        self.ui.pushButton_20.clicked.connect(self.performCheckin)
        self.ui.pushButton_21.clicked.connect(self.performcheckout)
        self.ui.pushButton_22.clicked.connect(self.performpaymentdetails)
        self.ui.pushButton_23.clicked.connect(self.performstaffdetails)
        self.ui.pushButton_26.clicked.connect(self.showHotelroyalin)
        self.ui.pushButton_24.clicked.connect(self.performFooddetails)
        self.ui.pushButton_34.clicked.connect(self.getCustomerDetails)
        self.ui.pushButton_27.clicked.connect(self.getRoomDetails)
        self.ui.pushButton_35.clicked.connect(self.getBookingDetails)
        self.ui.pushButton_28.clicked.connect(self.getCheckinDetails)
        self.ui.pushButton_29.clicked.connect(self.getCheckoutDetails)
        self.ui.pushButton_30.clicked.connect(self.getPaymentDetails)
        self.ui.pushButton_31.clicked.connect(self.getStaffDetails)
        self.ui.pushButton_32.clicked.connect(self.getFoodDetails)
        self.ui.comboBox_15.currentIndexChanged.connect(self.updateAmount)
        self.ui.pushButton_38.clicked.connect(self.checkcheckin)
        self.ui.pushButton_39.clicked.connect(self.checkcheckout)
        self.ui.pushButton_33.clicked.connect(self.CheckPayment)
        self.ui.pushButton_41.clicked.connect(self.CheckFood)


        


        MainWindow.show()
        sys.exit(app.exec_())

    def showSignUp(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.page)

    def showForgotPassword(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_2)

    def showHotelManagementDashboard(self):
        self.ui.stackedWidget_2.setCurrentWidget(self.ui.page_3)

    def showCustomerDetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_6)

    def showRoomDetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_7)

    def showBookingDetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_4)

    def showCheckin(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_5)

    def showCheckout(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_8)

    def showPaymentDetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_9)

    def showstaffdetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_10)


    def showfoodetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_11)

    def showHotelroyalin(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.stackedWidgetPage1)

    def showsignup(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.page)

    def logout(self):
        self.ui.stackedWidget_2.setCurrentWidget(self.ui.stackedWidget_2Page1)
        
    def showHotelroyalin(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.stackedWidgetPage1)
    
    def ShowDetails(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.page_12)

    def Dashboard(self):
        self.ui.stackedWidget_17.setCurrentWidget(self.ui.stackedWidget_17Page1)


    
    
    def performSignup(self):
        firstname = self.ui.lineEdit_3.text()
        lastname = self.ui.lineEdit_4.text()
        emailaddress = self.ui.lineEdit_5.text()
        contactnumber = self.ui.lineEdit_6.text()
        password = self.ui.lineEdit_7.text()
        self.db.saveUser(emailaddress,firstname,lastname,password,contactnumber)
        print('User Saved')



    def performLogin(self):
        username = self.ui.lineEdit.text()
        password = self.ui.lineEdit_2.text()
        r=self.db.validateUser(username,password)
        
        if r[0] ==1:
            self.ui.stackedWidget_2.setCurrentWidget(self.ui.page_3)
            print("Sucess login")
        else:
            print("Failed login")



    def performForgotPassword(self):
        username = self.ui.lineEdit_8.text()
        password = self.ui.lineEdit_9.text()
        reenterpassword = self.ui.lineEdit_10
        self.db.updatepassword(password,username)
        print('User saved')

    def performCustomerDetails(self):
        name = self.ui.lineEdit_14.text()
        mobileno = self.ui.lineEdit_15.text()
        idproof = self.ui.comboBox_2.currentText()
        idproofnumber = self.ui.lineEdit_12.text() 
        s = self.db.Addcustomer(name, mobileno, idproof, idproofnumber)
        print('s is',s)
        if s == 1:
            QMessageBox.information(None, "Success", "Customer Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('Customer details savedSucessfull')

    def performRoomdetails(self):
        roomno =self.ui.lineEdit_23.text()
        roomtype = self.ui.comboBox.currentText()
        roomprice = self.ui.comboBox_3.currentText()
        roomstatus = self.ui.comboBox_4.currentText()
        s= self.db.Addroom(roomno, roomtype, roomprice, roomstatus)
        print("Room detailsSucessfull")
        if s == 1:
            QMessageBox.information(None, "Success", "Room Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('Room details savedSucessfull')

    def performBookingDetails(Self):
        bookingid = Self.ui.lineEdit_11.text()
        customerid = Self.ui.lineEdit_16.text()
        roomno = Self.ui.comboBox_15.currentText()
        checkin = Self.ui.lineEdit_18.text()
        checkout = Self.ui.lineEdit_19.text()
        s=Self.db.Addbooking(bookingid ,customerid, roomno, checkin ,checkout)
        print("Booking Confirmed")

        if s == 1:
            QMessageBox.information(None, "Success", "Booking Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('Booking details savedSucessfull')

    def performCheckin(self):
        customerid = self.ui.lineEdit_21.text()
        checkindate = self.ui.lineEdit_17.text()
        checkoutdate= self.ui.lineEdit_34.text()
        s = self.db.Addcheckin(customerid,checkindate,checkoutdate)
        print("Sucessfully checkin")
        if s == 1:
            QMessageBox.information(None, "Success", "Checkin Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('Checkin details savedSucessfull')

    def performcheckout(self):
        bookingid = self.ui.lineEdit_24.text()
        Customerid = self.ui.lineEdit_25.text()
        Name = self.ui.lineEdit_22.text()
        Roomnumber = self.ui.lineEdit_26.text()
        Mobilenumber = self.ui.lineEdit_27.text()
        Checkout = self.ui.lineEdit_28.text()
        s = self.db.Addcheckout(Customerid,Name,Roomnumber,Mobilenumber,Checkout)
        print("checkout")
        if s == 1:
            QMessageBox.information(None, "Success", "Checkout Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")
        print('Checkout details savedSucessfull')

    def performpaymentdetails(self):
        bookingid = self.ui.lineEdit_29.text()
        guestname = self.ui.lineEdit_37.text()
        Totalamount = self.ui.lineEdit_31.text()
        TNXIDREFNO = self.ui.lineEdit_44.text()
        TNXtype = self.ui.comboBox_7.currentText()
        s = self.db.Addpayment( bookingid,guestname,Totalamount,TNXIDREFNO,TNXtype)
        print("payment confirmed")
        if s == 1:
            QMessageBox.information(None, "Success", "paymentdetails Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('paymentdetails saved Sucessfull')

    def performstaffdetails(self):
        staffname = self.ui.lineEdit_45.text()
        staffid = self.ui.lineEdit_47.text()
        gender = self.ui.comboBox_9.currentText()
        Designation = self.ui.comboBox_10.currentText()
        Department = self.ui.comboBox_11.currentText()
        Mobileno = self.ui.lineEdit_48.text()
        Shift = self.ui.comboBox_12.currentText()
        Salary = self.ui.lineEdit_50.text()
        JoiningDate = self.ui.lineEdit_49.text()
        Status = self.ui.comboBox_13.currentText()
        s = self.db.Addstaff(staffname,staffid,gender,Designation,Department,Mobileno,Shift,Salary,JoiningDate,Status)
        print('s is', s)
        print("Staff details verified")
        if s == 1:
            QMessageBox.information(None, "Success", "staffdetails Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('staffdetails saved Sucessfull')


    def performFooddetails(self):
        Bookingid = self.ui.lineEdit_33.text()
        Customerid = self.ui.lineEdit_30.text()
        Name = self.ui.lineEdit_36.text()
        Roomno = self.ui.lineEdit_32.text()
        Foodname = self.ui.lineEdit_35.text()
        Quantity = self.ui.comboBox_14.currentText()
        Timings = self.ui.lineEdit_38.text()
        s = self.db.AddFood(Customerid,Name,Roomno, Foodname,Quantity,Timings)
        print('s is', s ) 
        print("Order confirmed")
        if s == 1:
            QMessageBox.information(None, "Success", "Fooddetails Saved Successfully.")
        elif s==3:
            QMessageBox.warning(None, 'Warning', 'User already exists.')
        else:       
            QMessageBox.critical(None, 'Error', 'Something went worng in database.')
        print("succesfully")

        print('Fooddetails saved Sucessfull')


    def performsaveuser(self):
        firstname = self.db()
        lastname = self.db()
        email = self.db()

  
    def showtable(self, columns, data):
        self.ui.tableWidget.setRowCount(len(data))   # number of rows
        self.ui.tableWidget.setColumnCount(len(data[0]))  # number of columns
        self.ui.tableWidget.setHorizontalHeaderLabels(columns)

        # Add data
        r=0 
        for d in data:
            c=0
            for v in d:
                self.ui.tableWidget.setItem(r, c, QTableWidgetItem(v))
                c+=1
            r+=1

    def getCustomerDetails(self):
        columns = ('Customer Name','Mobile number','ID proof','ID proof number')
        data = self.db.CustomerDetails()
        self.showtable(columns, data)

    def getRoomDetails(self):
        columns = ('Room number','Room Type','Room Price','Room Status')
        data = self.db.RoomDetails()
        self.showtable(columns,data)
     
    def getBookingDetails(self):
        columns = ('Booking Id', 'Customer Id','Roomno', 'Checkin','Check Out')
        data = self.db.BookingDetails()
        self.showtable(columns,data)
 
    def getCheckinDetails(self):
        columns = ('Customerid','checkindate','checkoutdate')
        data = self.db.CheckinDetails()
        self.showtable(columns,data)

    def getCheckoutDetails(self):
        columns = ( 'Customer ID', 'Name','Room Number', 'Mobile Number','Checkout')
        data = self.db.CheckoutDetails()
        print(data)
        self.showtable(columns, data)

    def getPaymentDetails(self):
        columns = ('bookingid', 'guestname', 'Totalamount', 'TNXIDREFNO','TNXtype')
        data = self.db.PaymentDetails()
        self.showtable(columns, data) 

    def getStaffDetails(self):
        columns = ('staffname','staffid','gender','Designation','Department','Mobileno','Shift','Salary','JoiningDate','Status')
        data = self.db.StaffDetails()
        self.showtable(columns,data)
    
    def getFoodDetails(self):
        columns = ('CustomerID','Customer Name', 'Roomnumber', 'Foodname','Quantity','Timings')
        data = self.db.FoodDetails()
        self.showtable(columns,data)


    def updateComboboxes(self):
        roomno = self.db.getRoomno()
        print(roomno)
        if roomno != None:
            roomno = list(map(lambda x: x[0],roomno))
            print(roomno)
            self.ui.comboBox_15.addItems(roomno)
        else:
            print('Rooms not found')
    def updateAmount(self):
        amt = self.db.getAmount(self.ui.comboBox_15.currentText())
        print('amt is',amt)
        self.ui.lineEdit_20.setText(amt[0])

# function bna rahe h by default data utha rahe h 

    def checkcheckin(self,bID):
        bookingid = self.ui.lineEdit_13.text()
        data = self.db.getCheckin(bookingid)

        if data:
            customerid,checkindate,checkoutdate = data
            self.ui.lineEdit_21.setText(customerid)
            self.ui.lineEdit_17.setText(checkindate)
            self.ui.lineEdit_34.setText(checkoutdate)
        else:
            print("NO Check IN Found")


    def checkcheckout(self,Bid):
        bookingid = self.ui.lineEdit_24.text()
        data = self.db.getCheckout(bookingid)


        if data:
            customerid,name,roomnumber,mobileno,checkout = data
            self.ui.lineEdit_25.setText(customerid)
            self.ui.lineEdit_22.setText(name)
            self.ui.lineEdit_26.setText(roomnumber)
            self.ui.lineEdit_27.setText(mobileno)
            self.ui.lineEdit_28.setText(checkout)
        else:
            print("NO Checkout Found")

    def CheckPayment(self, bId):
        bookingid = self.ui.lineEdit_29.text()
        data = self.db.getPaymentBookingData(bookingid)

        if data:
            guestname, totalamount = data
            self.ui.lineEdit_37.setText(guestname)
            self.ui.lineEdit_31.setText(str(totalamount))
        else:
            print("No booking found!")

    def CheckFood(self,Bid):
        bookingid = self.ui.lineEdit_33.text()
        data = self.db.getfood(bookingid)

        if data:
            Customerid,Name,roomno= data
            self.ui.lineEdit_30.setText(Customerid)
            self.ui.lineEdit_36.setText(Name)
            self.ui.lineEdit_32.setText(roomno)

        else:
            print("NO FOOD record found")




    def loadDashboard(self):

        self.ui.label_25.setText(str(self.db.getTotalRooms()))
        self.ui.label_28.setText(str(self.db.getAvailableRooms()))
        self.ui.label_26.setText(str(self.db.getTotalBooking()))
        self.ui.label_30.setText(str(self.db.getTotalCustomer()))
        self.ui.label_27.setText(str(self.db.getBookedRooms()))
        self.ui.label_31.setText(str(self.db.getCheckin()))
        self.ui.label_32.setText(str(self.db.getFood()))
        self.ui.label_29.setText(str(self.db.getTotalPayment()))


if __name__ == "__main__":
    Handler()
    